This directory contains geographic information metadata for various test
datasets used by Hillview.