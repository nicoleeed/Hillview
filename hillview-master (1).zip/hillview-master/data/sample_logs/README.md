This directory contains various log fragments in various formats.
These are used as tests for Hillview log parsing logic.