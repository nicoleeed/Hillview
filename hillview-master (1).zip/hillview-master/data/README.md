This directory contains test data for Hillview
in various formats.