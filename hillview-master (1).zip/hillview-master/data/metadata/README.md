This directory contains additional centralized metadata
for various Hillview test datasets.  The metadata
can include 
- privacy-related parameters for differentially-private views
- geographic metadata, that links columns in the data with
  geographic information files