This directory contains differential-privacy-related 
metadata for tables loaded from the `employees` 
mysql database.