This folder contains Java code for implementing the Hillview back-end services.

To build the project from the command-line:

> $: mvn install

Alternatively, you can just run `../bin/rebuild.sh`

