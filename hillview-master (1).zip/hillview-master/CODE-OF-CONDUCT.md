We use the standard [Code of conduct](https://www.contributor-covenant.org/version/2/0/code_of_conduct/).

