This directory is a maven repository that contains optional jars that
are not public (e.g., Impala and Greenplum JDBC).  These jars are not
checked-in as part of the git repository.