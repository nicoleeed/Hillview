This directory will contain views which are bookmarked when running on the local machine.
